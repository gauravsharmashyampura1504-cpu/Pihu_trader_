CREATE TABLE IF NOT EXISTS click_attribution (
  token TEXT PRIMARY KEY,
  invite_link TEXT UNIQUE NOT NULL,
  fbp TEXT,
  fbc TEXT,
  user_agent TEXT,
  ip TEXT,
  landing_url TEXT,
  referrer TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  event_sent BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS meta_events (
  event_id TEXT PRIMARY KEY,
  token TEXT NOT NULL REFERENCES click_attribution(token) ON DELETE CASCADE,
  telegram_user_id TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_click_invite ON click_attribution(invite_link);

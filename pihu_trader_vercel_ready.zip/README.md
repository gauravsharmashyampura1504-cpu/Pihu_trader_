# PIHU TRADER — Vercel version

This version is designed for Vercel Functions and a persistent Neon Postgres database.

Flow:
Meta ad → landing page PageView → unique Telegram join-request invite → Telegram chat_join_request → Vercel Function → Meta Conversions API Subscribe.

## Deploy

1. Import this folder into Vercel.
2. Vercel Project Settings → Node.js Version: use 24.x. Vercel currently defaults new projects to Node 24 and Node 20 is deprecated for new deployments.
3. Add Neon from Vercel Marketplace/Storage. Neon is a Vercel-native serverless Postgres integration. It will provide `DATABASE_URL`.
4. In Neon SQL Editor run `schema.sql`.
5. Add environment variables from `.env.example`. Keep tokens as Secret variables. Do NOT prefix secrets with NEXT_PUBLIC_.
6. Redeploy after changing environment variables.
7. Open:
   `https://YOUR-PROJECT.vercel.app/api/setup-webhook?key=YOUR_SETUP_KEY`
8. It should return `ok: true`.
9. Check:
   `https://YOUR-PROJECT.vercel.app/api/status?key=YOUR_SETUP_KEY`

## Telegram

Create a bot with BotFather and make it an administrator of the channel. It needs the permission required to invite users / manage join requests.

The landing page does NOT use the static Telegram invite directly. Each click calls `/api/join-link`, which creates a unique invite link with `creates_join_request:true`. That link is saved with the browser's `_fbp` / `_fbc` attribution data. When Telegram sends `chat_join_request`, its invite link is used to recover the matching attribution record.

## Meta

Browser Pixel sends PageView only.

The `Subscribe` event is sent server-side after the Telegram `chat_join_request` is received. The implementation uses Meta Conversions API and an event_id to avoid duplicate Subscribe events.

Create a Conversions API access token for the dataset/pixel and put it in `META_ACCESS_TOKEN`.

## Testing

For Meta Test Events, temporarily put the Test Events code into `META_TEST_EVENT_CODE`, redeploy, send a test join request, and watch the event appear. Remove the test code for production.

## Important

- Never put Telegram bot token or Meta access token in frontend JavaScript.
- Never commit a real `.env`.
- Telegram and Meta policy eligibility is separate from technical tracking.
- Review and adapt the Terms/Privacy/Disclaimer pages for the actual operator and jurisdiction.

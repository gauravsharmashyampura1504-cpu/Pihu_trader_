import { neon } from "@neondatabase/serverless";
import crypto from "crypto";

export const runtime = "nodejs";

const sql = neon(process.env.DATABASE_URL);
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

function ip(req) {
  const x = req.headers.get("x-forwarded-for");
  return x ? x.split(",")[0].trim() : null;
}
async function telegram(method, body) {
  const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    headers: {"content-type":"application/json"},
    body: JSON.stringify(body)
  });
  const data = await r.json();
  if (!r.ok || !data.ok) throw new Error(`Telegram ${method}: ${JSON.stringify(data)}`);
  return data.result;
}

export async function POST(req) {
  try {
    if (!BOT_TOKEN || !CHAT_ID || !process.env.DATABASE_URL) {
      return Response.json({error:"Server is not configured"}, {status:500});
    }

    const body = await req.json().catch(()=>({}));
    const token = crypto.randomBytes(16).toString("hex");

    const invite = await telegram("createChatInviteLink", {
      chat_id: CHAT_ID,
      name: `meta_${token.slice(0,10)}`,
      creates_join_request: true
    });

    await sql`
      INSERT INTO click_attribution
      (token, invite_link, fbp, fbc, user_agent, ip, landing_url, referrer, created_at)
      VALUES
      (${token}, ${invite.invite_link}, ${body.fbp || null}, ${body.fbc || null},
       ${req.headers.get("user-agent") || null}, ${ip(req)}, ${body.landing_url || null},
       ${body.referrer || null}, NOW())
    `;

    return Response.json({url: invite.invite_link});
  } catch (e) {
    console.error(e);
    return Response.json({error:"Could not create Telegram invite"}, {status:500});
  }
}
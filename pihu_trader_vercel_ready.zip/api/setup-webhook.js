export const runtime = "nodejs";

const BOT_TOKEN=process.env.TELEGRAM_BOT_TOKEN;
const WEBHOOK_SECRET=process.env.TELEGRAM_WEBHOOK_SECRET;
const SETUP_KEY=process.env.SETUP_KEY;
const BASE_URL=(process.env.BASE_URL || `https://${process.env.VERCEL_URL || ""}`).replace(/\/$/,"");

async function telegram(method,body){
  const r=await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`,{
    method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)
  });
  const data=await r.json();
  if(!r.ok || !data.ok) throw new Error(JSON.stringify(data));
  return data.result;
}
export async function GET(req){
  const url=new URL(req.url);
  if(!SETUP_KEY || url.searchParams.get("key")!==SETUP_KEY) return new Response("Forbidden",{status:403});
  if(!BOT_TOKEN || !BASE_URL) return Response.json({ok:false,error:"Missing bot token or BASE_URL"},{status:500});
  const webhookUrl=`${BASE_URL}/api/telegram-webhook`;
  const result=await telegram("setWebhook",{
    url:webhookUrl,
    allowed_updates:["chat_join_request"],
    drop_pending_updates:false,
    ...(WEBHOOK_SECRET?{secret_token:WEBHOOK_SECRET}:{})
  });
  return Response.json({ok:true,webhookUrl,telegram:result});
}
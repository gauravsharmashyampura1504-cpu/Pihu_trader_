import { neon } from "@neondatabase/serverless";
export const runtime="nodejs";
const sql=neon(process.env.DATABASE_URL);
const BOT_TOKEN=process.env.TELEGRAM_BOT_TOKEN;
const SETUP_KEY=process.env.SETUP_KEY;
async function tg(method){
 const r=await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`);
 return await r.json();
}
export async function GET(req){
 const u=new URL(req.url);
 if(!SETUP_KEY || u.searchParams.get("key")!==SETUP_KEY) return new Response("Forbidden",{status:403});
 const clicks=await sql`SELECT COUNT(*)::int AS count FROM click_attribution`;
 const subs=await sql`SELECT COUNT(*)::int AS count FROM meta_events`;
 const bot=await tg("getMe");
 const wh=await tg("getWebhookInfo");
 return Response.json({bot,webhook:wh,click_records:clicks[0].count,meta_subscribes:subs[0].count});
}
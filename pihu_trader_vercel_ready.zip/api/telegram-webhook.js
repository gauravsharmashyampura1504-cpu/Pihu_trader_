import { neon } from "@neondatabase/serverless";
import crypto from "crypto";

export const runtime = "nodejs";

const sql = neon(process.env.DATABASE_URL);
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const META_PIXEL_ID = process.env.META_PIXEL_ID || "1757564198848437";
const META_ACCESS_TOKEN = process.env.META_ACCESS_TOKEN;
const META_API_VERSION = process.env.META_API_VERSION || "v26.0";
const TEST_EVENT_CODE = process.env.META_TEST_EVENT_CODE || "";
const WEBHOOK_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET;

function now(){return Math.floor(Date.now()/1000)}

function timingSafeEqual(a,b){
  if(!a || !b) return false;
  const aa=Buffer.from(a), bb=Buffer.from(b);
  return aa.length===bb.length && crypto.timingSafeEqual(aa,bb);
}

async function sendMeta(click, user) {
  const eventId = `tg_join_${click.token}_${user.id}`;
  const existing = await sql`SELECT event_id FROM meta_events WHERE event_id=${eventId} LIMIT 1`;
  if(existing.length) return;

  const userData = {};
  if(click.ip) userData.client_ip_address = click.ip;
  if(click.user_agent) userData.client_user_agent = click.user_agent;
  if(click.fbp) userData.fbp = click.fbp;
  if(click.fbc) userData.fbc = click.fbc;

  const event = {
    event_name:"Subscribe",
    event_time:now(),
    event_id:eventId,
    action_source:"website",
    event_source_url:click.landing_url || "https://example.com/",
    user_data:userData,
    custom_data:{source:"telegram_join_request"}
  };

  const payload={data:[event]};
  if(TEST_EVENT_CODE) payload.test_event_code=TEST_EVENT_CODE;

  const r=await fetch(
    `https://graph.facebook.com/${META_API_VERSION}/${META_PIXEL_ID}/events?access_token=${encodeURIComponent(META_ACCESS_TOKEN)}`,
    {method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payload)}
  );
  const out=await r.json();
  if(!r.ok || out.error) throw new Error(`Meta CAPI: ${JSON.stringify(out)}`);

  await sql`
    INSERT INTO meta_events(event_id, token, telegram_user_id, created_at)
    VALUES(${eventId}, ${click.token}, ${String(user.id)}, NOW())
    ON CONFLICT (event_id) DO NOTHING
  `;
  await sql`UPDATE click_attribution SET event_sent=true WHERE token=${click.token}`;
}

export async function POST(req) {
  try {
    if(WEBHOOK_SECRET){
      const received=req.headers.get("x-telegram-bot-api-secret-token");
      if(!timingSafeEqual(received,WEBHOOK_SECRET)) return new Response("Unauthorized",{status:401});
    }

    const update=await req.json().catch(()=>({}));
    const jr=update.chat_join_request;
    if(!jr) return Response.json({ok:true});

    const invite=jr.invite_link?.invite_link;
    if(!invite) return Response.json({ok:true});

    const rows=await sql`SELECT * FROM click_attribution WHERE invite_link=${invite} LIMIT 1`;
    if(!rows.length) return Response.json({ok:true});

    if(!META_ACCESS_TOKEN) throw new Error("META_ACCESS_TOKEN missing");
    await sendMeta(rows[0],jr.from);

    return Response.json({ok:true});
  } catch(e) {
    console.error("Telegram webhook error:",e);
    return Response.json({ok:false},{status:200});
  }
}